const settings = {
  packname: 'B͎E͎N͎Z͎I͎ C͎O͎M͎P͎A͎N͎Y͎ X͎M͎D͎',
  author: '‎',
  botName: "B͎E͎N͎Z͎ C͎O͎M͎P͎A͎N͎Y͎ X͎M͎D͎",
  botOwner: '👑ALPHA-KING👑', // Your name
  ownerNumber: '263718728504', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "This is a bot for managing group commands and automating tasks.",
  version: "2.0.8",
};

module.exports = settings;
